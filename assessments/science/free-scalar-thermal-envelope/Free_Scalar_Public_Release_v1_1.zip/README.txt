FREE SCALAR AUDIT PUBLIC RESEARCH EDITION 1.1
28 October 2026

Disposition: Ready for public release after the targeted corrections in this package. This is an editorial/evidence-scope release assessment, not proof of the conjectures, independent expert certification, or fresh execution.

The eight-page public PDF preserves the substantive analysis. Three private replay links were removed. The source authors' AI acknowledgement is corrected: problem selection was not supported by the inspected acknowledgement. Full author credit distinguishes Herzog and Stergiou's original research from Grounded DI's model-assisted audit. Supporting packages remain private. Original PDF and private archives are not included.

Machine-readable files:
- report_full_text.txt: complete searchable text with page breaks and table layout.
- report_full_text.json: page-addressable full text and public links.
- tables.json: typed numeric rows, preserving displayed precision.
- equations.json: explicit LaTeX for key equations and source page numbers.
- release_audit.json: claim/evidence map, limits, provenance and changes.
- source_citation.bib and source_citation.csl.json: citation for the ORIGINAL PAPER.
- publication_copy.txt: proposed caption, author credit and focused hashtags.
- SHA256SUMS.txt: hashes of all other package files (not a self-hash).

Important evidence limit: recovered original results contain 136 numeric leaves excluding booleans. That is not 136 independent tests. The separate second-pass execution receipt for the report's historical byte-match claim was not recovered. No scientific test was rerun for this release. Main source PDF and radial code/output hashes match recovered records. Public replay access is not promised.

The PDF is searchable but not tagged or PDF/UA certified. Text/JSON companions support machine reading; they do not make the PDF accessibility-certified. Equations/tables should be consumed with their page context and qualifications.

The modified PDF does not carry the original embedded C2PA credential; that original provenance cannot attest changed bytes. The original is privately preserved. New delivery systems may attach their own content credentials.

No publication or repository change was performed. Exact repository: https://github.com/Grounded-DI/DI-Space- . No license for Grounded DI materials is newly granted by this package.
